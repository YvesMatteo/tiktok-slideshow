#!/bin/zsh
# Import this run's slides into the macOS Photos app.
# iCloud Photos will sync them to your iPhone automatically if enabled.
echo "Importing 7 slides into Photos..."
osascript <<'APPLESCRIPT'
tell application "Photos"
  activate
  import {POSIX file "/home/runner/work/tiktok-slideshow/tiktok-slideshow/runs_collage/2026-07-30_105801/slide_00.jpg", POSIX file "/home/runner/work/tiktok-slideshow/tiktok-slideshow/runs_collage/2026-07-30_105801/slide_01.jpg", POSIX file "/home/runner/work/tiktok-slideshow/tiktok-slideshow/runs_collage/2026-07-30_105801/slide_02.jpg", POSIX file "/home/runner/work/tiktok-slideshow/tiktok-slideshow/runs_collage/2026-07-30_105801/slide_03.jpg", POSIX file "/home/runner/work/tiktok-slideshow/tiktok-slideshow/runs_collage/2026-07-30_105801/slide_04.jpg", POSIX file "/home/runner/work/tiktok-slideshow/tiktok-slideshow/runs_collage/2026-07-30_105801/slide_05.jpg", POSIX file "/home/runner/work/tiktok-slideshow/tiktok-slideshow/runs_collage/2026-07-30_105801/slide_06.jpg"}
end tell
APPLESCRIPT
echo ""
echo "Done. Photos has opened. iCloud will sync to your iPhone shortly."
echo "(closing in 3 seconds)"
sleep 3
