#!/bin/zsh
# Import this run's slides into the macOS Photos app.
# iCloud Photos will sync them to your iPhone automatically if enabled.
echo "Importing 6 slides into Photos..."
osascript <<'APPLESCRIPT'
tell application "Photos"
  activate
  import {POSIX file "/tmp/cv_workflow_2175/tiktok-slideshow/runs_workflow/2026-07-16_172130/slide_00.jpg", POSIX file "/tmp/cv_workflow_2175/tiktok-slideshow/runs_workflow/2026-07-16_172130/slide_01.jpg", POSIX file "/tmp/cv_workflow_2175/tiktok-slideshow/runs_workflow/2026-07-16_172130/slide_02.jpg", POSIX file "/tmp/cv_workflow_2175/tiktok-slideshow/runs_workflow/2026-07-16_172130/slide_03.jpg", POSIX file "/tmp/cv_workflow_2175/tiktok-slideshow/runs_workflow/2026-07-16_172130/slide_04.jpg", POSIX file "/tmp/cv_workflow_2175/tiktok-slideshow/runs_workflow/2026-07-16_172130/slide_05.jpg"}
end tell
APPLESCRIPT
echo ""
echo "Done. Photos has opened. iCloud will sync to your iPhone shortly."
echo "(closing in 3 seconds)"
sleep 3
